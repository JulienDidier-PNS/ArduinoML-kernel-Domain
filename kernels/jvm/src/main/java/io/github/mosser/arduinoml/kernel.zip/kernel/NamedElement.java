package io.github.mosser.arduinoml.kernel;


public interface NamedElement {

	public void setName(String name);
	public String getName();

}
