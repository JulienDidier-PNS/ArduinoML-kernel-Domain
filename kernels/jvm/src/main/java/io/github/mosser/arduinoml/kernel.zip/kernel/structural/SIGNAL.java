package io.github.mosser.arduinoml.kernel.structural;

public enum SIGNAL {
	HIGH,
	LOW
}
